# Whisper-Tiny Multi-lingual Transcriber
**NeuralChain Blockchain Verified AI Asset**

- **Model ID**: model-whisper-tiny-onnx
- **Category**: Audio
- **Framework**: ONNX
- **Model Format**: ONNX (.onnx)
- **SHA-256 Hash**: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- **IPFS CID**: `QmWhisperTinyMultilingualONNX98432176435678abcdef`
- **Verification Score**: 98/100 (Status: verified)
- **License**: MIT / Open-Access

---

## Quickstart

Run inference locally using Python:

```bash
pip install onnxruntime numpy Pillow safetensors torch
python infer.py
```

## Cryptographic Provenance
This model was purchased through the NeuralChain Decentralized AI Marketplace.
Proof of non-transferable access rights is verified on the blockchain.
